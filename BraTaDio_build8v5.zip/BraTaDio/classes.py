import tkinter as tk
from datetime import time


if __name__ == '__main__':
    menu = Menu()
    menu.mainloop()